"use client";

import React, { useEffect, useMemo, useRef, useState } from "react";
import { layoutPedigree, type TreeApiData } from "@/lib/pedigreeLayout";

type PedigreeCanvasProps = {
  data: TreeApiData | null;
  onSelectPerson: (id: string) => void;
};

type Viewport = { k: number; tx: number; ty: number };

export function PedigreeCanvas({ data, onSelectPerson }: PedigreeCanvasProps) {
  // Layout tuning (keep in one place)
  const NODE_W = 240;
  const NODE_H = 74;

  const layout = useMemo(() => {
    if (!data) return null;

    return layoutPedigree({
      data,
      options: {
        nodeW: NODE_W,
        nodeH: NODE_H,
        hGap: 18,
        vGap: 90,
        maxDepthUp: 4,
        maxDepthDown: 6,
        maxNodes: 1200,
      },
    });
  }, [data]);

  const svgRef = useRef<SVGSVGElement | null>(null);

  // SINGLE camera system (vp)
  const [vp, setVp] = useState<Viewport>({ k: 1, tx: 0, ty: 0 });

  // Pan gesture state
  const dragRef = useRef<{
    active: boolean;
    startClientX: number;
    startClientY: number;
    startTx: number;
    startTy: number;
    pointerId: number | null;
  }>({ active: false, startClientX: 0, startClientY: 0, startTx: 0, startTy: 0, pointerId: null });

  function clamp(n: number, lo: number, hi: number) {
    return Math.max(lo, Math.min(hi, n));
  }

  function getSvgClientRect() {
    const el = svgRef.current;
    if (!el) return null;
    return el.getBoundingClientRect();
  }

  function clientToWorld(clientX: number, clientY: number, v: Viewport) {
    const rect = getSvgClientRect();
    if (!rect) return { x: 0, y: 0 };
    const sx = clientX - rect.left;
    const sy = clientY - rect.top;
    // world = (screen - translate) / scale
    return { x: (sx - v.tx) / v.k, y: (sy - v.ty) / v.k };
  }

  // Auto-fit zoom, but center on the ROOT PERSON instead of the whole bounds
useEffect(() => {
  if (!layout || !svgRef.current) return;

  const rect = svgRef.current.getBoundingClientRect();
  const w = Math.max(1, rect.width);
  const h = Math.max(1, rect.height);

  const pad = 80;
  const bw = Math.max(1, layout.bounds.maxX - layout.bounds.minX);
  const bh = Math.max(1, layout.bounds.maxY - layout.bounds.minY);

  const k = clamp(Math.min((w - pad) / bw, (h - pad) / bh), 0.15, 2.5);

  const rootNode = layout.nodes.find((n) => n.id === layout.centerId);
  if (!rootNode) {
    setVp({ k, tx: 0, ty: 0 });
    return;
  }

  const rootCx = rootNode.x + NODE_W / 2;
  const rootCy = rootNode.y + NODE_H / 2;

  const tx = w / 2 - rootCx * k;
  const ty = h / 2 - rootCy * k;

  setVp({ k, tx, ty });
}, [layout]);

  // Wheel zoom (zoom to cursor)
  function onWheel(e: React.WheelEvent<SVGSVGElement>) {
    e.preventDefault();
    if (!svgRef.current) return;

    const delta = e.deltaY;
    const factor = delta > 0 ? 0.92 : 1.08;

    setVp((prev) => {
      const k2 = clamp(prev.k * factor, 0.1, 4);

      const before = clientToWorld(e.clientX, e.clientY, prev);
      const after = clientToWorld(e.clientX, e.clientY, { ...prev, k: k2 });

      // Keep cursor anchored: adjust translate by world-delta * scale
      const tx2 = prev.tx + (after.x - before.x) * k2;
      const ty2 = prev.ty + (after.y - before.y) * k2;

      return { k: k2, tx: tx2, ty: ty2 };
    });
  }

  function onPointerDown(e: React.PointerEvent<SVGSVGElement>) {
    if (e.button !== 0) return;
    const el = svgRef.current;
    if (!el) return;

    el.setPointerCapture(e.pointerId);

    dragRef.current.active = true;
    dragRef.current.pointerId = e.pointerId;
    dragRef.current.startClientX = e.clientX;
    dragRef.current.startClientY = e.clientY;
    dragRef.current.startTx = vp.tx;
    dragRef.current.startTy = vp.ty;
  }

  function onPointerMove(e: React.PointerEvent<SVGSVGElement>) {
    if (!dragRef.current.active) return;

    const dx = e.clientX - dragRef.current.startClientX;
    const dy = e.clientY - dragRef.current.startClientY;

    setVp((prev) => ({
      ...prev,
      tx: dragRef.current.startTx + dx,
      ty: dragRef.current.startTy + dy,
    }));
  }

  function onPointerUp(e: React.PointerEvent<SVGSVGElement>) {
    if (!dragRef.current.active) return;

    dragRef.current.active = false;
    dragRef.current.pointerId = null;

    const el = svgRef.current;
    if (el) {
      try {
        el.releasePointerCapture(e.pointerId);
      } catch {
        // ignore
      }
    }
  }

  if (!layout) {
    return (
      <div style={{ border: "1px solid #e5e7eb", borderRadius: 12, padding: 12, color: "#6b7280" }}>
        Loading pedigree…
      </div>
    );
  }

  // helper to lookup node meta from API
  const metaById = new Map<string, { fullName: string; claimedByUserId: string | null }>();
  for (const n of data?.nodes ?? []) {
    metaById.set(n.id, { fullName: n.fullName ?? "Unnamed", claimedByUserId: n.claimedByUserId ?? null });
  }

  return (
    <div
      style={{
        width: "100%",
        height: "calc(100vh - 120px)",
        border: "1px solid #e5e7eb",
        borderRadius: 12,
        overflow: "hidden",
      }}
    >
      <svg
        ref={svgRef}
        width="100%"
        height="100%"
        style={{ background: "#ffffff", touchAction: "none" }}
        onWheel={onWheel}
        onPointerDown={onPointerDown}
        onPointerMove={onPointerMove}
        onPointerUp={onPointerUp}
      >
        <g transform={`translate(${vp.tx} ${vp.ty}) scale(${vp.k})`}>
          {/* edges */}
          <g>
            {layout.edges.map((e, idx) => (
              <path
                key={`${e.kind}:${e.fromId ?? ""}:${e.toId ?? ""}:${idx}`}
                d={e.pathD}
                fill="none"
                stroke="#111827"
                strokeWidth={2}
                strokeLinecap="round"
                opacity={e.kind === "sibship" ? 0.55 : 0.9}
              />
            ))}
          </g>

          {/* nodes */}
          <g>
            {layout.nodes.map((n) => {
              const meta = metaById.get(n.id);
              const name = meta?.fullName ?? "Unnamed";
              const claimedByUserId = meta?.claimedByUserId ?? null;

              return (
                <foreignObject key={n.id} x={n.x} y={n.y} width={NODE_W} height={NODE_H}>
                  <div style={{ width: NODE_W, height: NODE_H }}>
                    <NodeCard
                      id={n.id}
                      name={name}
                      claimedByUserId={claimedByUserId}
                      onClick={() => onSelectPerson(n.id)}
                    />
                  </div>
                </foreignObject>
              );
            })}
          </g>
        </g>
      </svg>
    </div>
  );
}

function NodeCard({
  id,
  name,
  claimedByUserId,
  onClick,
}: {
  id: string;
  name: string;
  claimedByUserId: string | null;
  onClick: () => void;
}) {
  const claimed = Boolean(claimedByUserId);

  return (
    <button
      type="button"
      onClick={onClick}
      style={{
        width: "100%",
        height: "100%",
        borderRadius: 14,
        border: "1px solid #e5e7eb",
        background: "#ffffff",
        padding: 12,
        cursor: "pointer",
        textAlign: "left",
        boxShadow: "0 1px 2px rgba(0,0,0,0.06)",
      }}
      title={id}
    >
      <div style={{ display: "flex", justifyContent: "space-between", gap: 10, alignItems: "center" }}>
        <div style={{ fontWeight: 800, color: "#111827", fontSize: 14, lineHeight: "18px" }}>{name}</div>
        <div style={{ fontSize: 11, fontWeight: 800, color: claimed ? "#16a34a" : "#f59e0b" }}>
          {claimed ? "CLAIMED" : "UNCLAIMED"}
        </div>
      </div>
      <div style={{ marginTop: 8, fontSize: 12, color: "#6b7280" }}>{id.slice(0, 8)}…</div>
    </button>
  );
}