"use client";

import { useState } from "react";

type Person = {
  id: string;
  fullName: string;
  createdAt: string;
  isPrivate: boolean;
  claimedByUserId?: string | null;
};

export type PersonGraph = {
  person: Person & {
    bio?: string | null;
    location?: string | null;
    birthDate?: string | null;
    deathDate?: string | null;
    photoUrl?: string | null;
  };
  parents: Person[];
  children: Person[];
  spouses: Person[];
  siblings: Person[];
  grandchildren: Person[];
  niecesNephews: Person[];
};

type TreeApiNode = {
  id: string;
  fullName?: string;
  isPrivate?: boolean;
  createdAt?: string;
  bio?: string | null;
  location?: string | null;
  birthDate?: string | null;
  deathDate?: string | null;
  photoUrl?: string | null;
  claimedByUserId?: string | null;
};

type TreeApiEdgePC = { parentId: string; childId: string };
type TreeApiEdgeSp = { aId: string; bId: string };

function safePerson(n: TreeApiNode): PersonGraph["person"] {
  return {
    id: n.id,
    fullName: n.fullName ?? "Unnamed",
    isPrivate: n.isPrivate ?? false,
    createdAt: n.createdAt ?? new Date().toISOString(),
    claimedByUserId: n.claimedByUserId ?? null,
    bio: n.bio ?? null,
    location: n.location ?? null,
    birthDate: n.birthDate ?? null,
    deathDate: n.deathDate ?? null,
    photoUrl: n.photoUrl ?? null,
  };
}

function pick(map: Map<string, TreeApiNode>, ids: string[]): Person[] {
  const out: Person[] = [];
  const seen = new Set<string>();

  for (const id of ids) {
    if (!id || seen.has(id)) continue;
    seen.add(id);

    const n = map.get(id);
    if (!n) continue;

    out.push({
      id: n.id,
      fullName: n.fullName ?? "Unnamed",
      isPrivate: n.isPrivate ?? false,
      createdAt: n.createdAt ?? new Date().toISOString(),
      claimedByUserId: n.claimedByUserId ?? null,
    });
  }

  return out;
}

function uniq(ids: string[]): string[] {
  return Array.from(new Set(ids.filter(Boolean)));
}

function titleCaseLabel(base: string, count: number) {
  return `${base}${count === 1 ? "" : "s"}`;
}

// Converts /api/tree response {centerId,nodes,edges} into PersonGraph
export function toPersonGraph(raw: any): PersonGraph {
  // If it already matches PersonGraph, normalize and return it.
 if (raw?.person && raw?.parents && raw?.children && raw?.spouses) {
  const normalized: PersonGraph = {
    ...raw,
    siblings: raw.siblings ?? [],
    grandchildren: raw.grandchildren ?? [],
    niecesNephews: raw.niecesNephews ?? [],
  };
  return normalized;
}

  const centerId: string | undefined = raw?.centerId;
  const nodes: TreeApiNode[] = Array.isArray(raw?.nodes) ? raw.nodes : [];
  const pc: TreeApiEdgePC[] = Array.isArray(raw?.edges?.parentChild) ? raw.edges.parentChild : [];
  const sp: TreeApiEdgeSp[] = Array.isArray(raw?.edges?.spouse) ? raw.edges.spouse : [];

  if (!centerId) throw new Error("TREE_MAP_MISSING_CENTER_ID");

  const map = new Map<string, TreeApiNode>();
  for (const n of nodes) {
    if (n?.id) map.set(n.id, n);
  }

  const centerNode = map.get(centerId);
  if (!centerNode) throw new Error("TREE_MAP_CENTER_NODE_NOT_FOUND");

  // Direct relatives
  const parentIds = pc.filter((e) => e.childId === centerId).map((e) => e.parentId);
  const childIds = pc.filter((e) => e.parentId === centerId).map((e) => e.childId);

  if (centerId === "064953cf-d6ed-4418-965d-ea8508c8eab9") {
  console.log("GC_DEBUG", {
    centerId,
    childIds,
    edgesFromChildren: pc.filter((e) => childIds.includes(e.parentId)),
  });
}

  const spouseIds = sp
    .filter((e) => e.aId === centerId || e.bId === centerId)
    .map((e) => (e.aId === centerId ? e.bId : e.aId));

  // Siblings = other children of my parents
  const myParentIds = parentIds;

  const siblingIds = uniq(
    pc
      .filter((e) => myParentIds.includes(e.parentId))
      .map((e) => e.childId)
      .filter((id) => id !== centerId)
  );

  // Grandchildren = children-of-my-children
  // If /api/tree depth < 2, some grandchildren won't exist in nodes; pick() will simply omit missing nodes.
  const grandchildIds = uniq(
    pc
      .filter((e) => childIds.includes(e.parentId))
      .map((e) => e.childId)
      .filter((id) => id !== centerId)
  );

  // Nieces/Nephews = children-of-my-siblings
  const niecesNephewsIds = uniq(
    pc
      .filter((e) => siblingIds.includes(e.parentId))
      .map((e) => e.childId)
      .filter((id) => id !== centerId)
  );

  return {
    person: safePerson(centerNode),
    parents: pick(map, parentIds),
    children: pick(map, childIds),
    spouses: pick(map, spouseIds),
    siblings: pick(map, siblingIds),
    grandchildren: pick(map, grandchildIds),
    niecesNephews: pick(map, niecesNephewsIds),
  };
}

function PersonRow({
  p,
  onSelect,
  onInvite,
  canInvite,
}: {
  p: Person;
  onSelect: (id: string) => void;
  onInvite: (personId: string, email: string) => Promise<void>;
  canInvite: boolean;
}) {
  const claimed = Boolean(p.claimedByUserId);
  const [email, setEmail] = useState("");
  const [busy, setBusy] = useState(false);

  return (
    <div style={{ border: "1px solid #e5e7eb", borderRadius: 10, padding: 10, marginBottom: 8 }}>
      <div style={{ display: "flex", justifyContent: "space-between", gap: 12, alignItems: "center" }}>
        <button
          onClick={() => onSelect(p.id)}
          style={{
            background: "transparent",
            border: "none",
            padding: 0,
            cursor: "pointer",
            fontWeight: 700,
            textAlign: "left",
          }}
        >
          {p.fullName}
        </button>

        <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
          <span style={{ fontSize: 12, fontWeight: 700, color: claimed ? "#16a34a" : "#f59e0b" }}>
            {claimed ? "CLAIMED" : "UNCLAIMED"}
          </span>
          <button
  type="button"
  onClick={() => navigator.clipboard.writeText(p.id)}
  style={{
    fontSize: 12,
    color: "#6b7280",
    border: "1px solid #d1d5db",
    background: "#fff",
    borderRadius: 8,
    padding: "4px 8px",
    cursor: "pointer",
  }}
>
  Copy ID
</button>
        </div>
      </div>

      {!claimed && canInvite && (
        <div style={{ marginTop: 10, display: "flex", gap: 8, flexWrap: "wrap", alignItems: "center" }}>
          <input
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="Invite email"
            style={{ padding: "8px 10px", borderRadius: 8, border: "1px solid #d1d5db", minWidth: 240 }}
          />
          <button
            disabled={busy || !email.trim()}
            onClick={async () => {
              const e = email.trim();
              if (!e) return;
              setBusy(true);
              try {
                await onInvite(p.id, e);
                setEmail("");
              } finally {
                setBusy(false);
              }
            }}
            style={{
              padding: "8px 12px",
              borderRadius: 8,
              border: "1px solid #111827",
              background: busy || !email.trim() ? "#e5e7eb" : "#111827",
              color: busy || !email.trim() ? "#111827" : "#ffffff",
              cursor: busy || !email.trim() ? "not-allowed" : "pointer",
              fontWeight: 700,
            }}
          >
            {busy ? "Inviting..." : "Invite"}
          </button>
          <div style={{ fontSize: 12, color: "#6b7280" }}>Creates a claim link for this profile.</div>
        </div>
      )}
    </div>
  );
}

function Section({
  title,
  people,
  onSelectPerson,
  onInvite,
  canInvite,
}: {
  title: string;
  people: Person[];
  onSelectPerson: (id: string) => void;
  onInvite: (personId: string, email: string) => Promise<void>;
  canInvite: boolean;
}) {
  if (!people || people.length === 0) return null;

  return (
    <div style={{ marginTop: 16 }}>
      <h4 style={{ margin: "0 0 8px 0" }}>
        {title} <span style={{ color: "#6b7280", fontWeight: 600 }}>({people.length})</span>
      </h4>
      {people.map((p) => (
        <PersonRow key={p.id} p={p} onSelect={onSelectPerson} onInvite={onInvite} canInvite={canInvite} />
      ))}
    </div>
  );
}

export function TreeView({
  graph,
  onSelectPerson,
  onInvite,
  canInvite,
}: {
  graph: PersonGraph;
  onSelectPerson: (id: string) => void;
  onInvite: (personId: string, email: string) => Promise<void>;
  canInvite: boolean;
}) {
  return (
    <div style={{ border: "1px solid #e5e7eb", padding: 12, borderRadius: 12 }}>
      <h3 style={{ marginTop: 0 }}>Selected</h3>
      <PersonRow p={graph.person} onSelect={onSelectPerson} onInvite={onInvite} canInvite={canInvite} />

      <Section title={titleCaseLabel("Parent", graph.parents.length)} people={graph.parents} onSelectPerson={onSelectPerson} onInvite={onInvite} canInvite={canInvite} />
      <Section title={titleCaseLabel("Sibling", graph.siblings.length)} people={graph.siblings} onSelectPerson={onSelectPerson} onInvite={onInvite} canInvite={canInvite} />
      <Section title={titleCaseLabel("Spouse", graph.spouses.length)} people={graph.spouses} onSelectPerson={onSelectPerson} onInvite={onInvite} canInvite={canInvite} />
      <Section title={titleCaseLabel("Child", graph.children.length)} people={graph.children} onSelectPerson={onSelectPerson} onInvite={onInvite} canInvite={canInvite} />

<Section
  title={titleCaseLabel("Grandchild", (graph.grandchildren ?? []).length)}
  people={graph.grandchildren ?? []}
  onSelectPerson={onSelectPerson}
  onInvite={onInvite}
  canInvite={canInvite}
/>

<Section
  title={titleCaseLabel("Niece / Nephew", (graph.niecesNephews ?? []).length)}
  people={graph.niecesNephews ?? []}
  onSelectPerson={onSelectPerson}
  onInvite={onInvite}
  canInvite={canInvite}
/>
    </div>
  );
}

/**
 * Dev-only validator you can run in the browser console:
 *   import { __devTestTreeDerivations } from "./TreeView";
 *   __devTestTreeDerivations();
 */
export function __devTestTreeDerivations() {
  // Graph:
  // G -> P
  // P -> (ME and SIB)
  // ME -> KID
  // KID -> GRANDKID
  // SIB -> NIECE
  const raw = {
    centerId: "ME",
    nodes: [
      { id: "G", fullName: "Grandparent" },
      { id: "P", fullName: "Parent" },
      { id: "ME", fullName: "Me" },
      { id: "SIB", fullName: "Sibling" },
      { id: "KID", fullName: "My Child" },
      { id: "GRANDKID", fullName: "My Grandchild" },
      { id: "NIECE", fullName: "Niece/Nephew" },
    ],
    edges: {
      parentChild: [
        { parentId: "G", childId: "P" },
        { parentId: "P", childId: "ME" },
        { parentId: "P", childId: "SIB" },
        { parentId: "ME", childId: "KID" },
        { parentId: "KID", childId: "GRANDKID" },
        { parentId: "SIB", childId: "NIECE" },
      ],
      spouse: [],
    },
  };

  const g = toPersonGraph(raw);

  const ids = (arr: Person[]) => arr.map((p) => p.id).sort();

  console.log("children:", ids(g.children));
  console.log("grandchildren:", ids(g.grandchildren));
  console.log("siblings:", ids(g.siblings));
  console.log("niecesNephews:", ids(g.niecesNephews));

  // Assertions
  if (ids(g.children).join(",") !== ["KID"].join(",")) throw new Error("TEST_FAIL: children");
  if (ids(g.grandchildren).join(",") !== ["GRANDKID"].join(",")) throw new Error("TEST_FAIL: grandchildren");
  if (ids(g.siblings).join(",") !== ["SIB"].join(",")) throw new Error("TEST_FAIL: siblings");
  if (ids(g.niecesNephews).join(",") !== ["NIECE"].join(",")) throw new Error("TEST_FAIL: niecesNephews");

  console.log("✅ __devTestTreeDerivations passed");
}