type Person = {
  id: string;
  fullName: string;
  createdAt: string;
  isPrivate: boolean;
  claimedByUserId?: string | null;
};

export type PersonGraph = {
  person: Person & {
    bio?: string | null;
    location?: string | null;
    birthDate?: string | null;
    deathDate?: string | null;
    photoUrl?: string | null;
  };
  parents: Person[];
  children: Person[];
  spouses: Person[];
  siblings: Person[];
};

type TreeApiNode = {
  id: string;
  fullName?: string;
  isPrivate?: boolean;
  createdAt?: string;
  bio?: string | null;
  location?: string | null;
  birthDate?: string | null;
  deathDate?: string | null;
  photoUrl?: string | null;
  claimedByUserId?: string | null;
};

type TreeApiEdgePC = { parentId: string; childId: string };
type TreeApiEdgeSp = { aId: string; bId: string };

function safePerson(n: TreeApiNode): PersonGraph["person"] {
  return {
    id: n.id,
    fullName: (n.fullName ?? "").trim() || "Unnamed",
    isPrivate: n.isPrivate ?? false,
    createdAt: n.createdAt ?? new Date().toISOString(),
    claimedByUserId: n.claimedByUserId ?? null,
    bio: n.bio ?? null,
    location: n.location ?? null,
    birthDate: n.birthDate ?? null,
    deathDate: n.deathDate ?? null,
    photoUrl: n.photoUrl ?? null,
  };
}

function pick(map: Map<string, TreeApiNode>, ids: string[]): Person[] {
  const out: Person[] = [];
  const seen = new Set<string>();

  for (const id of ids) {
    if (seen.has(id)) continue;
    seen.add(id);

    const n = map.get(id);
    if (!n) continue;

    out.push({
      id: n.id,
      fullName: (n.fullName ?? "").trim() || "Unnamed",
      isPrivate: n.isPrivate ?? false,
      createdAt: n.createdAt ?? new Date().toISOString(),
      claimedByUserId: n.claimedByUserId ?? null,
    });
  }

  return out;
}

// Converts /api/tree response {centerId,nodes,edges} into PersonGraph {person,parents,children,spouses,siblings}
export function toPersonGraph(raw: any): PersonGraph {
  if (!raw?.centerId) throw new Error("TREE_MAP_MISSING_CENTER_ID");

  const centerId: string = raw.centerId;
  const nodes: TreeApiNode[] = Array.isArray(raw?.nodes) ? raw.nodes : [];
  const pc: TreeApiEdgePC[] = Array.isArray(raw?.edges?.parentChild)
    ? raw.edges.parentChild
    : [];
  const sp: TreeApiEdgeSp[] = Array.isArray(raw?.edges?.spouse)
    ? raw.edges.spouse
    : [];

  const map = new Map<string, TreeApiNode>();
  for (const n of nodes) {
    if (n?.id) map.set(n.id, n);
  }

  const centerNode = map.get(centerId);
  if (!centerNode) throw new Error("TREE_MAP_CENTER_NODE_NOT_FOUND");

  // --------------------
  // BASIC RELATIONSHIPS
  // --------------------

  const parentIds = pc
    .filter((e) => e.childId === centerId)
    .map((e) => e.parentId);

  const childIds = pc
    .filter((e) => e.parentId === centerId)
    .map((e) => e.childId);

  const spouseIds = sp
    .filter((e) => e.aId === centerId || e.bId === centerId)
    .map((e) => (e.aId === centerId ? e.bId : e.aId));

  const siblingIds = Array.from(
    new Set(
      pc
        .filter((e) => parentIds.includes(e.parentId))
        .map((e) => e.childId)
        .filter((id) => id !== centerId)
    )
  );

  // --------------------
  // GRANDCHILDREN
  // --------------------

  const grandchildIds = Array.from(
    new Set(
      pc
        .filter((e) => childIds.includes(e.parentId))
        .map((e) => e.childId)
        .filter((id) => id !== centerId)
    )
  );

  // --------------------
  // NIECES / NEPHEWS
  // --------------------

  const nieceNephewIds = Array.from(
    new Set(
      pc
        .filter((e) => siblingIds.includes(e.parentId))
        .map((e) => e.childId)
        .filter((id) => id !== centerId)
    )
  );

  return {
    person: safePerson(centerNode),
    parents: pick(map, parentIds),
    children: pick(map, childIds),
    spouses: pick(map, spouseIds),
    siblings: pick(map, siblingIds),
    grandchildren: pick(map, grandchildIds),
    niecesNephews: pick(map, nieceNephewIds),
  };
}