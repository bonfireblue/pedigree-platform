// src/lib/pedigreeLayout.ts

export type TreeApiNode = {
  id: string;
  fullName?: string;
  claimedByUserId?: string | null;
  isPrivate?: boolean;
  createdAt?: string;
  bio?: string | null;
  location?: string | null;
  birthDate?: string | null;
  deathDate?: string | null;
  photoUrl?: string | null;
};

export type TreeApiEdgePC = { parentId: string; childId: string };
export type TreeApiEdgeSp = { aId: string; bId: string };

export type TreeApiData = {
  centerId: string;
  depth?: number;
  limit?: number;
  nodes: TreeApiNode[];
  edges: {
    parentChild: TreeApiEdgePC[];
    spouse: TreeApiEdgeSp[];
  };
};

export type LayoutOptions = {
  nodeW: number;
  nodeH: number;
  hGap: number;
  vGap: number;
  maxDepthUp: number;
  maxDepthDown: number;
  maxNodes: number;
};

export type PositionedNode = {
  id: string;
  x: number;
  y: number;
  gen: number;
  kind: "person";
};

export type RoutedEdge = {
  kind: "spouse" | "parentChild";
  pathD: string;
  fromId?: string;
  toId?: string;
  unionId?: string;
};

export type LayoutResult = {
  centerId: string;
  nodes: PositionedNode[];
  edges: RoutedEdge[];
  bounds: { minX: number; minY: number; maxX: number; maxY: number };
};

type Union = {
  id: string;
  aId: string;
  bId: string;
  gen: number;
  childIds: string[];
};

type Block = {
  id: string;
  gen: number;
  personIds: string[]; // 1 or 2
  childBlockIds: string[];
};

export function layoutPedigree(params: { data: TreeApiData; options: LayoutOptions }): LayoutResult {
  const { data, options } = params;
  const centerId = data.centerId;

  const nodeW = options.nodeW;
  const nodeH = options.nodeH;
  const hGap = options.hGap;
  const vGap = options.vGap;

  const pc = Array.isArray(data.edges?.parentChild) ? data.edges.parentChild : [];
  const sp = Array.isArray(data.edges?.spouse) ? data.edges.spouse : [];

  // --------------------------------------------------
  // Helpers
  // --------------------------------------------------
  function stableSortIds(ids: string[]) {
    return ids.slice().sort((a, b) => {
      const na = (nodeById.get(a)?.fullName ?? "").toLowerCase();
      const nb = (nodeById.get(b)?.fullName ?? "").toLowerCase();
      if (na !== nb) return na < nb ? -1 : 1;
      return a < b ? -1 : 1;
    });
  }

  function unionKey(a: string, b: string) {
    return a < b ? `${a}|${b}` : `${b}|${a}`;
  }

  function blockWidth(personIds: string[]) {
    return personIds.length === 2 ? nodeW * 2 + hGap : nodeW;
  }

  // --------------------------------------------------
  // A) Index data
  // --------------------------------------------------
  const nodeById = new Map<string, TreeApiNode>();
  for (const n of data.nodes ?? []) {
    if (n?.id) nodeById.set(n.id, n);
  }

  const parentsByChild = new Map<string, string[]>();
  const childrenByParent = new Map<string, string[]>();

  for (const e of pc) {
    if (!e?.parentId || !e?.childId) continue;

    if (!parentsByChild.has(e.childId)) parentsByChild.set(e.childId, []);
    parentsByChild.get(e.childId)!.push(e.parentId);

    if (!childrenByParent.has(e.parentId)) childrenByParent.set(e.parentId, []);
    childrenByParent.get(e.parentId)!.push(e.childId);
  }

  for (const [k, arr] of parentsByChild.entries()) {
    parentsByChild.set(k, Array.from(new Set(arr)));
  }

  for (const [k, arr] of childrenByParent.entries()) {
    childrenByParent.set(k, Array.from(new Set(arr)));
  }

  const spousesById = new Map<string, string[]>();
  function addSpouse(a: string, b: string) {
    if (!spousesById.has(a)) spousesById.set(a, []);
    spousesById.get(a)!.push(b);
  }

  for (const e of sp) {
    if (!e?.aId || !e?.bId) continue;
    addSpouse(e.aId, e.bId);
    addSpouse(e.bId, e.aId);
  }

  for (const [k, arr] of spousesById.entries()) {
    spousesById.set(k, Array.from(new Set(arr)));
  }

  // --------------------------------------------------
  // B) Bloodline traversal only (prevents in-law parents)
  // --------------------------------------------------
  const genById = new Map<string, number>();
  const distById = new Map<string, number>();

  genById.set(centerId, 0);
  distById.set(centerId, 0);

  const q: string[] = [centerId];

  while (q.length > 0 && genById.size < options.maxNodes) {
    const cur = q.shift()!;
    const curGen = genById.get(cur)!;
    const curDist = distById.get(cur)!;

    if (curGen > -options.maxDepthUp) {
      for (const p of parentsByChild.get(cur) ?? []) {
        if (!nodeById.has(p)) continue;
        if (genById.has(p)) continue;
        genById.set(p, curGen - 1);
        distById.set(p, curDist + 1);
        q.push(p);
      }
    }

    if (curGen < options.maxDepthDown) {
      for (const c of childrenByParent.get(cur) ?? []) {
        if (!nodeById.has(c)) continue;
        if (genById.has(c)) continue;
        genById.set(c, curGen + 1);
        distById.set(c, curDist + 1);
        q.push(c);
      }
    }
  }

  const include = new Set<string>(Array.from(genById.keys()));

  // Add spouses at same generation, but do not traverse spouse parents
  for (const id of Array.from(include)) {
    const g = genById.get(id)!;
    for (const mate of spousesById.get(id) ?? []) {
      if (!nodeById.has(mate)) continue;
      include.add(mate);
      if (!genById.has(mate)) {
        genById.set(mate, g);
        distById.set(mate, (distById.get(id) ?? 0) + 1);
      }
    }
  }

  // --------------------------------------------------
  // C) Build unions
  // --------------------------------------------------
  const unionByKey = new Map<string, Union>();

  for (const e of sp) {
    if (!e?.aId || !e?.bId) continue;
    if (!include.has(e.aId) || !include.has(e.bId)) continue;

    const ga = genById.get(e.aId);
    const gb = genById.get(e.bId);

    if (typeof ga !== "number" || typeof gb !== "number") continue;
    if (ga !== gb) continue;

    const key = unionKey(e.aId, e.bId);
    if (!unionByKey.has(key)) {
      unionByKey.set(key, {
        id: key,
        aId: e.aId,
        bId: e.bId,
        gen: ga,
        childIds: [],
      });
    }
  }

  // --------------------------------------------------
  // D) Assign children to unions
  // --------------------------------------------------
  const unionForChild = new Map<string, string>();
  const parentsInclByChild = new Map<string, string[]>();

  for (const [childId, parentIds] of parentsByChild.entries()) {
    const visibleParents = parentIds.filter((pid) => include.has(pid));
    if (visibleParents.length > 0) {
      parentsInclByChild.set(childId, visibleParents);
    }
  }

  for (const u of unionByKey.values()) {
    u.childIds = [];
  }

  function visibleUnionKeysForParent(parentId: string): string[] {
    const mates = (spousesById.get(parentId) ?? []).filter((m) => include.has(m));
    const keys: string[] = [];
    for (const mate of mates) {
      const key = unionKey(parentId, mate);
      if (unionByKey.has(key)) keys.push(key);
    }
    return stableSortIds(keys);
  }

  for (const [childId, visibleParents] of parentsInclByChild.entries()) {
    const sortedParents = stableSortIds(visibleParents);

    if (sortedParents.length >= 2) {
      let matchedUnion: string | null = null;

      for (let i = 0; i < sortedParents.length; i++) {
        for (let j = i + 1; j < sortedParents.length; j++) {
          const key = unionKey(sortedParents[i], sortedParents[j]);
          if (unionByKey.has(key)) {
            matchedUnion = key;
            break;
          }
        }
        if (matchedUnion) break;
      }

      if (matchedUnion) {
        unionForChild.set(childId, matchedUnion);
        unionByKey.get(matchedUnion)!.childIds.push(childId);
        continue;
      }
    }

    if (sortedParents.length === 1) {
      const onlyParent = sortedParents[0];
      const parentUnionKeys = visibleUnionKeysForParent(onlyParent);

      if (parentUnionKeys.length === 1) {
        const key = parentUnionKeys[0];
        unionForChild.set(childId, key);
        unionByKey.get(key)!.childIds.push(childId);
      }
    }
  }

  for (const u of unionByKey.values()) {
    u.childIds = stableSortIds(Array.from(new Set(u.childIds)));
  }

  console.log(
    "UNIONS_DEBUG_JSON",
    JSON.stringify(
      Array.from(unionByKey.values()).map((u) => ({
        union: `${nodeById.get(u.aId)?.fullName ?? u.aId} + ${nodeById.get(u.bId)?.fullName ?? u.bId}`,
        childNames: u.childIds.map((id) => nodeById.get(id)?.fullName ?? id),
      })),
      null,
      2
    )
  );

  // --------------------------------------------------
  // E) Build blocks (union pair or single)
  // --------------------------------------------------
  const blocks = new Map<string, Block>();
  const personToBlockId = new Map<string, string>();

  const paired = new Set<string>();

  const unionsSorted = Array.from(unionByKey.values()).sort((a, b) => {
    if (a.gen !== b.gen) return a.gen - b.gen;
    const da = Math.min(distById.get(a.aId) ?? 1e9, distById.get(a.bId) ?? 1e9);
    const db = Math.min(distById.get(b.aId) ?? 1e9, distById.get(b.bId) ?? 1e9);
    if (da !== db) return da - db;
    return a.id < b.id ? -1 : 1;
  });

  for (const u of unionsSorted) {
    if (paired.has(u.aId) || paired.has(u.bId)) continue;

    const pair = stableSortIds([u.aId, u.bId]);
    const blockId = `block:${u.id}`;

    blocks.set(blockId, {
      id: blockId,
      gen: u.gen,
      personIds: pair,
      childBlockIds: [],
    });

    personToBlockId.set(pair[0], blockId);
    personToBlockId.set(pair[1], blockId);

    paired.add(pair[0]);
    paired.add(pair[1]);
  }

  for (const id of stableSortIds(Array.from(include))) {
    if (personToBlockId.has(id)) continue;

    const blockId = `block:${id}`;
    blocks.set(blockId, {
      id: blockId,
      gen: genById.get(id)!,
      personIds: [id],
      childBlockIds: [],
    });
    personToBlockId.set(id, blockId);
  }

  // --------------------------------------------------
  // F) Parent block -> child block relationships
  // --------------------------------------------------
  const incomingParentCount = new Map<string, number>();
  for (const blockId of blocks.keys()) incomingParentCount.set(blockId, 0);

  function addChildBlock(parentBlockId: string, childBlockId: string) {
    if (parentBlockId === childBlockId) return;

    const parentBlock = blocks.get(parentBlockId);
    if (!parentBlock) return;

    if (!parentBlock.childBlockIds.includes(childBlockId)) {
      parentBlock.childBlockIds.push(childBlockId);
      incomingParentCount.set(childBlockId, (incomingParentCount.get(childBlockId) ?? 0) + 1);
    }
  }

  // union-based children
  for (const u of unionByKey.values()) {
    const parentBlockId = personToBlockId.get(u.aId);
    if (!parentBlockId) continue;

    for (const childId of u.childIds) {
      const childBlockId = personToBlockId.get(childId);
      if (!childBlockId) continue;
      addChildBlock(parentBlockId, childBlockId);
    }
  }

  // single-parent fallbacks
  for (const e of pc) {
    if (!include.has(e.parentId) || !include.has(e.childId)) continue;
    if (unionForChild.has(e.childId)) continue;

    const parentBlockId = personToBlockId.get(e.parentId);
    const childBlockId = personToBlockId.get(e.childId);
    if (!parentBlockId || !childBlockId) continue;
    addChildBlock(parentBlockId, childBlockId);
  }

  // sort child block ids by current child order from data
  for (const block of blocks.values()) {
    const seen = new Set<string>();
    block.childBlockIds = block.childBlockIds.filter((id) => {
      if (seen.has(id)) return false;
      seen.add(id);
      return true;
    });

    block.childBlockIds.sort((a, b) => {
      const aName = (blocks.get(a)?.personIds[0] ?? "").toLowerCase();
      const bName = (blocks.get(b)?.personIds[0] ?? "").toLowerCase();
      return aName < bName ? -1 : aName > bName ? 1 : 0;
    });
  }

  // --------------------------------------------------
  // G) Top-down centered subtree layout
  // --------------------------------------------------
  const blockCenterX = new Map<string, number>();
  const nodeY = new Map<string, number>();

  for (const block of blocks.values()) {
    nodeY.set(block.id, block.gen * (nodeH + vGap));
  }

  const subtreeWidth = new Map<string, number>();

  function computeSubtreeWidth(blockId: string): number {
    if (subtreeWidth.has(blockId)) return subtreeWidth.get(blockId)!;

    const block = blocks.get(blockId)!;
    const own = blockWidth(block.personIds);

    if (block.childBlockIds.length === 0) {
      subtreeWidth.set(blockId, own);
      return own;
    }

    const childWidths = block.childBlockIds.map((cid) => computeSubtreeWidth(cid));
    const totalChildren =
      childWidths.reduce((sum, w) => sum + w, 0) + hGap * Math.max(0, childWidths.length - 1);

    const width = Math.max(own, totalChildren);
    subtreeWidth.set(blockId, width);
    return width;
  }

  const rootBlockIds = Array.from(blocks.values())
    .filter((b) => (incomingParentCount.get(b.id) ?? 0) === 0)
    .sort((a, b) => {
      if (a.gen !== b.gen) return a.gen - b.gen;

      const da = Math.min(...a.personIds.map((id) => distById.get(id) ?? 1e9));
      const db = Math.min(...b.personIds.map((id) => distById.get(id) ?? 1e9));
      if (da !== db) return da - db;

      const an = (nodeById.get(a.personIds[0])?.fullName ?? "").toLowerCase();
      const bn = (nodeById.get(b.personIds[0])?.fullName ?? "").toLowerCase();
      if (an !== bn) return an < bn ? -1 : 1;
      return a.id < b.id ? -1 : 1;
    })
    .map((b) => b.id);

  for (const rootId of rootBlockIds) computeSubtreeWidth(rootId);

  function layoutBlock(blockId: string, centerX: number) {
    blockCenterX.set(blockId, centerX);

    const block = blocks.get(blockId)!;
    if (block.childBlockIds.length === 0) return;

  // Keep the immediate children of a block packed tightly as siblings.
// Do NOT let one deep subtree create huge whitespace between siblings.
const childBlockWidths = block.childBlockIds.map((cid) => {
  const childBlock = blocks.get(cid)!;
  return blockWidth(childBlock.personIds);
});

const totalChildren =
  childBlockWidths.reduce((sum, w) => sum + w, 0) +
  hGap * Math.max(0, childBlockWidths.length - 1);

let left = centerX - totalChildren / 2;

for (let i = 0; i < block.childBlockIds.length; i++) {
  const childId = block.childBlockIds[i];
  const childBlock = blocks.get(childId)!;
  const w = childBlockWidths[i];
  const childCenter = left + w / 2;

  layoutBlock(childId, childCenter);

  left += w + hGap;
}

  const forestWidth =
    rootBlockIds.reduce((sum, id) => sum + (subtreeWidth.get(id) ?? 0), 0) +
    hGap * Math.max(0, rootBlockIds.length - 1);

  let forestLeft = -forestWidth / 2;

  for (const rootId of rootBlockIds) {
    const w = subtreeWidth.get(rootId)!;
    layoutBlock(rootId, forestLeft + w / 2);
    forestLeft += w + hGap;
  }

  // --------------------------------------------------
  // H) Convert block centers to node positions
  // --------------------------------------------------
  const nodeX = new Map<string, number>();

  for (const block of blocks.values()) {
    const cx = blockCenterX.get(block.id) ?? 0;
    const width = blockWidth(block.personIds);
    const left = cx - width / 2;

    if (block.personIds.length === 2) {
      const [aId, bId] = block.personIds;
      nodeX.set(aId, left);
      nodeX.set(bId, left + nodeW + hGap);
    } else {
      nodeX.set(block.personIds[0], cx - nodeW / 2);
    }
  }

  // Center around the selected/root person or root couple midpoint
  const rootBlockId = personToBlockId.get(centerId);
  if (rootBlockId) {
    const rootBlock = blocks.get(rootBlockId)!;
    const rootMid = blockCenterX.get(rootBlockId) ?? 0;

    for (const [id, value] of nodeX.entries()) {
      nodeX.set(id, value - rootMid);
    }
  }

  // --------------------------------------------------
  // I) Positioned nodes
  // --------------------------------------------------
  const positioned: PositionedNode[] = [];

  for (const id of include) {
    const x = nodeX.get(id);
    const y = genById.get(id);

    if (typeof x !== "number" || typeof y !== "number") continue;

    positioned.push({
      id,
      x,
      y: y * (nodeH + vGap),
      gen: y,
      kind: "person",
    });
  }

  const posById = new Map<string, PositionedNode>();
  for (const p of positioned) posById.set(p.id, p);

  // --------------------------------------------------
  // J) Edges
  // --------------------------------------------------
  const edgesOut: RoutedEdge[] = [];

  const posCenterX = (id: string) => (posById.get(id)?.x ?? 0) + nodeW / 2;
  const posTopY = (id: string) => posById.get(id)?.y ?? 0;
  const posMidY = (id: string) => (posById.get(id)?.y ?? 0) + nodeH / 2;

  // spouse edges
  for (const u of unionByKey.values()) {
    const a = posById.get(u.aId);
    const b = posById.get(u.bId);
    if (!a || !b) continue;
    if (a.gen !== b.gen) continue;

    const yLine = a.y + nodeH / 2;
    const x1 = posCenterX(u.aId);
    const x2 = posCenterX(u.bId);

    edgesOut.push({
      kind: "spouse",
      unionId: u.id,
      fromId: u.aId,
      toId: u.bId,
      pathD: `M ${Math.min(x1, x2)} ${yLine} L ${Math.max(x1, x2)} ${yLine}`,
    });
  }

  // union -> child routing
  for (const u of unionByKey.values()) {
    const a = posById.get(u.aId);
    const b = posById.get(u.bId);
    if (!a || !b) continue;
    if (a.gen !== b.gen) continue;

    const kids = (u.childIds ?? [])
      .map((cid) => posById.get(cid))
      .filter(Boolean) as PositionedNode[];

    if (kids.length === 0) continue;

    const childGen = a.gen + 1;
    const rowKids = kids.filter((k) => k.gen === childGen);
    if (rowKids.length === 0) continue;

    rowKids.sort((k1, k2) => k1.x - k2.x);

    const ux = (posCenterX(u.aId) + posCenterX(u.bId)) / 2;
    const uy = posMidY(u.aId);

    const childTopMin = Math.min(...rowKids.map((k) => k.y));
    const sibY = Math.max(uy + 24, childTopMin - Math.max(20, vGap * 0.35));

    edgesOut.push({
      kind: "parentChild",
      unionId: u.id,
      pathD: `M ${ux} ${uy} L ${ux} ${sibY}`,
    });

    if (rowKids.length === 1) {
      const onlyKid = rowKids[0];
      const kx = onlyKid.x + nodeW / 2;
      const kt = onlyKid.y;

      edgesOut.push({
        kind: "parentChild",
        unionId: u.id,
        fromId: u.aId,
        toId: onlyKid.id,
        pathD: `M ${ux} ${sibY} L ${kx} ${sibY} L ${kx} ${kt}`,
      });
    } else {
      const leftChildCenter = rowKids[0].x + nodeW / 2;
      const rightChildCenter = rowKids[rowKids.length - 1].x + nodeW / 2;

      edgesOut.push({
        kind: "parentChild",
        unionId: u.id,
        pathD: `M ${leftChildCenter} ${sibY} L ${rightChildCenter} ${sibY}`,
      });

      for (const k of rowKids) {
        const kx = k.x + nodeW / 2;
        const kt = k.y;

        edgesOut.push({
          kind: "parentChild",
          unionId: u.id,
          fromId: u.aId,
          toId: k.id,
          pathD: `M ${kx} ${sibY} L ${kx} ${kt}`,
        });
      }
    }
  }

  // single-parent fallbacks
  for (const e of pc) {
    if (!e?.parentId || !e?.childId) continue;
    if (!include.has(e.parentId) || !include.has(e.childId)) continue;
    if (unionForChild.has(e.childId)) continue;

    const p = posById.get(e.parentId);
    const c = posById.get(e.childId);
    if (!p || !c) continue;
    if (c.gen !== p.gen + 1) continue;

    const px = posCenterX(e.parentId);
    const py = posMidY(e.parentId);
    const cy = posTopY(e.childId);
    const jY = Math.max(py + 20, cy - Math.max(20, vGap * 0.35));

    edgesOut.push({
      kind: "parentChild",
      fromId: e.parentId,
      toId: e.childId,
      pathD: `M ${px} ${py} L ${px} ${jY} L ${px} ${cy}`,
    });
  }

  // --------------------------------------------------
  // K) Bounds
  // --------------------------------------------------
  let minX = Infinity;
  let minY = Infinity;
  let maxX = -Infinity;
  let maxY = -Infinity;

  for (const n of positioned) {
    minX = Math.min(minX, n.x);
    minY = Math.min(minY, n.y);
    maxX = Math.max(maxX, n.x + nodeW);
    maxY = Math.max(maxY, n.y + nodeH);
  }

  if (!isFinite(minX)) minX = 0;
  if (!isFinite(minY)) minY = 0;
  if (!isFinite(maxX)) maxX = 0;
  if (!isFinite(maxY)) maxY = 0;

  return {
    centerId,
    nodes: positioned,
    edges: edgesOut,
    bounds: { minX, minY, maxX, maxY },
  };
}