import { NextResponse } from "next/server";
import { randomBytes } from "crypto";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/db";
import { readJson } from "@/lib/body";

function isVerifiedRole(role: string) {
  return role === "FOUNDER" || role === "TRUSTED" || role === "ADMIN";
}

async function computeCanInvite(params: { meId: string; familyGraphId: string; role: string }) {
  const { meId, familyGraphId, role } = params;

  // Verified roles can always invite
  if (isVerifiedRole(role)) return true;

  // MEMBER: allowed ONLY if they are among founder's first 10 ACCEPTED invitees
  const graph = await prisma.familyGraph.findUnique({
    where: { id: familyGraphId },
    select: { createdById: true },
  });
  if (!graph) return false;

  // Defensive: founder can always invite
  if (graph.createdById === meId) return true;

  const firstTenAccepted = await prisma.invitation.findMany({
    where: {
      familyGraphId,
      inviterUserId: graph.createdById,
      status: "ACCEPTED",
      acceptedByUserId: { not: null },
    },
    orderBy: { acceptedAt: "asc" },
    take: 10,
    select: { acceptedByUserId: true },
  });

  return firstTenAccepted.some((r) => r.acceptedByUserId === meId);
}

export async function POST(req: Request) {
  const session = await getServerSession(authOptions);
  if (!session?.user?.email) {
    return NextResponse.json({ error: "UNAUTHORIZED" }, { status: 401 });
  }

  const me = await prisma.user.findUnique({
    where: { email: session.user.email },
    select: { id: true, email: true },
  });
  if (!me) {
    return NextResponse.json({ error: "UNAUTHORIZED" }, { status: 401 });
  }

  // NOTE: if later you support multiple graphs per user, you'll want
  // the client to send familyGraphId explicitly.
  const membership = await prisma.membership.findFirst({
    where: { userId: me.id },
    select: { familyGraphId: true, role: true },
    orderBy: { createdAt: "asc" },
  });

  if (!membership) {
    return NextResponse.json({ error: "NO_MEMBERSHIP" }, { status: 403 });
  }

  const canInvite = await computeCanInvite({
    meId: me.id,
    familyGraphId: membership.familyGraphId,
    role: membership.role,
  });

  if (!canInvite) {
    return NextResponse.json({ error: "NOT_VERIFIED_TO_INVITE" }, { status: 403 });
  }

  const parsed = await readJson(req);
  if (!parsed.ok) {
    return NextResponse.json({ error: parsed.error }, { status: 400 });
  }

  const { targetPersonId, email } = parsed.json;

  if (!targetPersonId || !email) {
    return NextResponse.json({ error: "MISSING_FIELDS" }, { status: 400 });
  }

  const person = await prisma.person.findFirst({
    where: {
      id: targetPersonId,
      familyGraphId: membership.familyGraphId,
    },
    select: { id: true, claimedByUserId: true },
  });

  if (!person) {
    return NextResponse.json({ error: "INVALID_PERSON" }, { status: 404 });
  }

  if (person.claimedByUserId) {
    return NextResponse.json({ error: "ALREADY_CLAIMED" }, { status: 400 });
  }

  const token = randomBytes(32).toString("hex");

  const invitation = await prisma.invitation.create({
    data: {
      token,
      email: String(email).trim().toLowerCase(),
      familyGraphId: membership.familyGraphId,
      targetPersonId,
      inviterUserId: me.id,
      expiresAt: new Date(Date.now() + 1000 * 60 * 60 * 24 * 7), // 7 days
    },
    select: { id: true, token: true },
  });

  const inviteUrl = `${process.env.NEXTAUTH_URL}/accept-invite?token=${invitation.token}`;

  return NextResponse.json({
    invitationId: invitation.id,
    inviteUrl,
  });
}