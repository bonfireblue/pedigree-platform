import { NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import { requireMe } from "@/lib/authz";
import { rateLimit, clientKey } from "@/lib/rateLimit";

type NodeRow = {
  id: string;
  fullName: string;
  isPrivate: boolean;
  createdById: string;
  createdAt: Date;
  bio: string | null;
  location: string | null;
  birthDate: Date | null;
  deathDate: Date | null;
  photoUrl: string | null;
  claimedByUserId: string | null;
  familyGraphId: string;
};

type ParentChildEdge = { parentId: string; childId: string };
type SpouseEdge = { aId: string; bId: string };

function canView(_meId: string, row: { isPrivate: boolean; createdById: string }) {
  // You said: “no privacy rule yet” — so allow all for now.
  // Keep this stub so you can re-enable later.
  if (!row.isPrivate) return true;
  return true;
}

export async function GET(req: Request) {
  const lim = rateLimit({ key: `tree:${clientKey(req)}`, limit: 120, windowMs: 60_000 });
  if (!lim.ok) return NextResponse.json({ error: "RATE_LIMIT" }, { status: 429 });

  const me = await requireMe();
  if (!me) return NextResponse.json({ error: "UNAUTHORIZED" }, { status: 401 });

  const { searchParams } = new URL(req.url);

  const centerId = searchParams.get("centerId") || "";
  const depth = Math.max(1, Math.min(4, Number(searchParams.get("depth") || "2")));
  const limit = Math.max(50, Math.min(1500, Number(searchParams.get("limit") || "800")));

  if (!centerId) return NextResponse.json({ error: "MISSING_CENTER_ID" }, { status: 400 });

  const center = (await prisma.person.findFirst({
    where: { id: centerId },
    select: {
      id: true,
      fullName: true,
      isPrivate: true,
      createdById: true,
      createdAt: true,
      bio: true,
      location: true,
      birthDate: true,
      deathDate: true,
      photoUrl: true,
      claimedByUserId: true,
      familyGraphId: true,
    },
  })) as unknown as NodeRow | null;

  if (!center) return NextResponse.json({ error: "NOT_FOUND" }, { status: 404 });

  const membership = await prisma.membership.findUnique({
    where: {
      userId_familyGraphId: {
        userId: me.id,
        familyGraphId: center.familyGraphId,
      },
    },
    select: { id: true, role: true, familyGraphId: true },
  });

  if (!membership) return NextResponse.json({ error: "FORBIDDEN" }, { status: 403 });
  if (!canView(me.id, center)) return NextResponse.json({ error: "FORBIDDEN" }, { status: 403 });

  const familyGraphId = center.familyGraphId;

  /**
   * IMPORTANT CHANGE (for your desired pedigree):
   * - We keep “blood expansion” via ParentChild only from BLOOD nodes.
   * - We still INCLUDE spouses (so the marriage shows),
   *   but we DO NOT expand upward into spouse parents.
   *
   * This prevents “spouse’s parents” from appearing in the pedigree.
   */
  type DiscoverKind = "blood" | "spouse";
  const kindById = new Map<string, DiscoverKind>();

  const visited = new Set<string>();
  const frontier: string[] = [centerId];
  visited.add(centerId);
  kindById.set(centerId, "blood");

  for (let d = 0; d < depth; d++) {
    if (visited.size >= limit) break;

    const batch = frontier.splice(0, frontier.length);
    if (batch.length === 0) break;

    // Only expand parent/child edges from BLOOD nodes.
    const bloodBatch = batch.filter((id) => kindById.get(id) !== "spouse");

    // Expand blood relatives (up/down)
    let parents: Array<{ parentId: string }> = [];
    let children: Array<{ childId: string }> = [];

    if (bloodBatch.length > 0) {
      parents = await prisma.parentChild.findMany({
        where: { childId: { in: bloodBatch } },
        select: { parentId: true },
      });

      children = await prisma.parentChild.findMany({
        where: { parentId: { in: bloodBatch } },
        select: { childId: true },
      });
    }

    // Always expand spouse edges from current batch so marriages show.
    const spousesA = await prisma.spouse.findMany({
      where: { aId: { in: batch } },
      select: { bId: true },
    });

    const spousesB = await prisma.spouse.findMany({
      where: { bId: { in: batch } },
      select: { aId: true },
    });

    const candidateSet = new Set<string>();

    // Blood expansion candidates
    for (const e of parents) candidateSet.add(e.parentId);
    for (const e of children) candidateSet.add(e.childId);

    // Spouse candidates (marked spouse if discovered ONLY via spouse)
    for (const s of spousesA) candidateSet.add(s.bId);
    for (const s of spousesB) candidateSet.add(s.aId);

    const rawCandidates = Array.from(candidateSet).filter((id) => !visited.has(id));
    if (rawCandidates.length === 0) continue;

    const remaining = Math.max(0, limit - visited.size);
    const cappedCandidates = rawCandidates.slice(0, Math.max(0, remaining));

    // Hard restrict to same FamilyGraph
    const inGraph = await prisma.person.findMany({
      where: { id: { in: cappedCandidates }, familyGraphId },
      select: { id: true },
    });

    const nextIds: string[] = [];
    for (const row of inGraph) {
      if (visited.size >= limit) break;
      const id = row.id;
      if (visited.has(id)) continue;

      visited.add(id);

      // Decide discovery kind:
      // If reached via parent/child from bloodBatch => blood.
      // Else if reached via spouse edge => spouse (unless already blood).
      // We approximate by checking if id is in parent/child candidate lists.
      let discoveredAs: DiscoverKind = "spouse";
      if (parents.some((p) => p.parentId === id)) discoveredAs = "blood";
      if (children.some((c) => c.childId === id)) discoveredAs = "blood";

      // If already known as blood, keep blood
      const prev = kindById.get(id);
      if (prev === "blood") discoveredAs = "blood";

      kindById.set(id, discoveredAs);
      nextIds.push(id);
    }

    frontier.push(...nextIds);
  }

  const nodesAll = (await prisma.person.findMany({
    where: { id: { in: Array.from(visited) }, familyGraphId },
    select: {
      id: true,
      fullName: true,
      isPrivate: true,
      createdById: true,
      createdAt: true,
      bio: true,
      location: true,
      birthDate: true,
      deathDate: true,
      photoUrl: true,
      claimedByUserId: true,
      familyGraphId: true,
    },
  })) as unknown as NodeRow[];

  const nodes = nodesAll.filter((n) => canView(me.id, n));
  const visibleIds = new Set(nodes.map((n) => n.id));

  const parentChildEdges = (await prisma.parentChild.findMany({
    where: {
      OR: [{ parentId: { in: Array.from(visibleIds) } }, { childId: { in: Array.from(visibleIds) } }],
    },
    select: { parentId: true, childId: true },
  })) as unknown as ParentChildEdge[];

  const spouseEdges = (await prisma.spouse.findMany({
    where: {
      OR: [{ aId: { in: Array.from(visibleIds) } }, { bId: { in: Array.from(visibleIds) } }],
    },
    select: { aId: true, bId: true },
  })) as unknown as SpouseEdge[];

  const pc = parentChildEdges.filter((e) => visibleIds.has(e.parentId) && visibleIds.has(e.childId));
  const sp = spouseEdges.filter((e) => visibleIds.has(e.aId) && visibleIds.has(e.bId));

  return NextResponse.json({
    centerId,
    depth,
    limit,
    nodes: nodes.map((n) => ({
      id: n.id,
      fullName: n.fullName,
      isPrivate: n.isPrivate,
      createdAt: n.createdAt.toISOString(),
      bio: n.bio,
      location: n.location,
      birthDate: n.birthDate ? n.birthDate.toISOString() : null,
      deathDate: n.deathDate ? n.deathDate.toISOString() : null,
      photoUrl: n.photoUrl,
      claimedByUserId: n.claimedByUserId,
    })),
    edges: {
      parentChild: pc,
      spouse: sp,
    },
  });
}