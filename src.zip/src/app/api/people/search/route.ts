import { NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import { requireMe } from "@/lib/authz";

export async function GET(req: Request) {
  const me = await requireMe();
  if (!me) return NextResponse.json({ error: "UNAUTHORIZED" }, { status: 401 });

  const { searchParams } = new URL(req.url);
  const q = (searchParams.get("q") || "").trim();
  const centerId = (searchParams.get("centerId") || "").trim();
  const limit = Math.max(5, Math.min(30, Number(searchParams.get("limit") || "15")));

  if (!q) return NextResponse.json({ results: [] });
  if (!centerId) return NextResponse.json({ error: "MISSING_CENTER_ID" }, { status: 400 });

  const center = await prisma.person.findFirst({
    where: { id: centerId },
    select: { familyGraphId: true },
  });
  if (!center) return NextResponse.json({ error: "CENTER_NOT_FOUND" }, { status: 404 });

  const membership = await prisma.membership.findUnique({
    where: {
      userId_familyGraphId: { userId: me.id, familyGraphId: center.familyGraphId },
    },
    select: { id: true },
  });
  if (!membership) return NextResponse.json({ error: "FORBIDDEN" }, { status: 403 });

  const results = await prisma.person.findMany({
    where: {
      familyGraphId: center.familyGraphId,
      fullName: { contains: q, mode: "insensitive" },
    },
    select: { id: true, fullName: true, claimedByUserId: true },
    take: limit,
    orderBy: { fullName: "asc" },
  });

  return NextResponse.json({
    results: results.map((p) => ({
      id: p.id,
      fullName: (p.fullName ?? "").trim() || "Unnamed",
      claimedByUserId: p.claimedByUserId,
    })),
  });
}