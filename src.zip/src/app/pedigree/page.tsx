"use client";

import Link from "next/link";
import { useEffect, useMemo, useState } from "react";
import { useSession } from "next-auth/react";
import { PedigreeCanvas } from "@/components/PedigreeCanvas";

type TreeApiNode = {
  id: string;
  fullName?: string;
  isPrivate?: boolean;
  createdAt?: string;
  bio?: string | null;
  location?: string | null;
  birthDate?: string | null;
  deathDate?: string | null;
  photoUrl?: string | null;
  claimedByUserId?: string | null;
};

type TreeApiEdgePC = { parentId: string; childId: string };
type TreeApiEdgeSp = { aId: string; bId: string };

type TreeApiResponse = {
  centerId: string;
  depth: number;
  limit: number;
  nodes: TreeApiNode[];
  edges: {
    parentChild: TreeApiEdgePC[];
    spouse: TreeApiEdgeSp[];
  };
};

export default function PedigreePage() {
  const { status } = useSession();

  const centerId = useMemo(() => {
    if (typeof window === "undefined") return null;
    const sp = new URLSearchParams(window.location.search);
    return sp.get("centerId");
  }, []);

  const [error, setError] = useState<string | null>(null);
  const [treeData, setTreeData] = useState<TreeApiResponse | null>(null);
  const [selectedId, setSelectedId] = useState<string | null>(centerId);

  // Redirect if signed out
  useEffect(() => {
    if (status === "unauthenticated") window.location.href = "/sign-in";
  }, [status]);

  async function loadTree(id: string) {
    setSelectedId(id);
    setError(null);

    // API currently supports depth 1–4. We'll ask for 4 so we can lay out more generations.
    const res = await fetch(`/api/tree?centerId=${encodeURIComponent(id)}&depth=4`);

    const data = (await res.json().catch(() => null)) as TreeApiResponse | null;

    if (!res.ok || !data) {
      setTreeData(null);
      setError((data as any)?.error ?? `TREE_LOAD_FAILED_${res.status}`);
      return;
    }

    setTreeData(data);
  }

  // CRUD helpers
  async function createPersonQuick(fullName: string) {
    const res = await fetch("/api/people", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ fullName, isPrivate: false }),
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(data?.error ?? `CREATE_FAILED_${res.status}`);
    return data.person.id as string;
  }

  async function linkParentChild(parentId: string, childId: string) {
    const res = await fetch("/api/relationships/parent-child", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ parentId, childId }),
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(data?.error ?? `LINK_PC_FAILED_${res.status}`);
  }

  async function linkSpouse(aId: string, bId: string) {
    const res = await fetch("/api/relationships/spouse", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ aId, bId }),
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(data?.error ?? `LINK_SPOUSE_FAILED_${res.status}`);
  }

  function getParentIds(childId: string): string[] {
    const pc = treeData?.edges?.parentChild ?? [];
    return pc.filter((e) => e.childId === childId).map((e) => e.parentId);
  }

  // initial load
  useEffect(() => {
    if (centerId) loadTree(centerId);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [centerId]);

  if (status === "loading") return null;

  return (
    <main style={{ minHeight: "100vh", padding: 24 }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", gap: 12 }}>
        <h1 style={{ margin: 0 }}>Pedigree</h1>

        <div style={{ display: "flex", gap: 10, flexWrap: "wrap", alignItems: "center" }}>
          <button
            type="button"
            disabled={!selectedId}
            onClick={async () => {
              if (!selectedId) return;
              const name = window.prompt("New parent full name:");
              if (!name?.trim()) return;
              try {
                const newId = await createPersonQuick(name.trim());
                await linkParentChild(newId, selectedId);
                await loadTree(selectedId);
              } catch (e: any) {
                setError(String(e?.message ?? e));
              }
            }}
          >
            Add Parent
          </button>

          <button
            type="button"
            disabled={!selectedId}
            onClick={async () => {
              if (!selectedId) return;
              const existingId = window.prompt("Existing parent ID to link:");
              if (!existingId?.trim()) return;
              try {
                await linkParentChild(existingId.trim(), selectedId);
                await loadTree(selectedId);
              } catch (e: any) {
                setError(String(e?.message ?? e));
              }
            }}
          >
            Link Existing Parent
          </button>

          <button
            type="button"
            disabled={!selectedId}
            onClick={async () => {
              if (!selectedId) return;
              const name = window.prompt("New child full name:");
              if (!name?.trim()) return;
              try {
                const newId = await createPersonQuick(name.trim());
                await linkParentChild(selectedId, newId);
                await loadTree(selectedId);
              } catch (e: any) {
                setError(String(e?.message ?? e));
              }
            }}
          >
            Add Child
          </button>

          <button
            type="button"
            disabled={!selectedId}
            onClick={async () => {
              if (!selectedId) return;
              const existingId = window.prompt("Existing child ID to link:");
              if (!existingId?.trim()) return;
              try {
                await linkParentChild(selectedId, existingId.trim());
                await loadTree(selectedId);
              } catch (e: any) {
                setError(String(e?.message ?? e));
              }
            }}
          >
            Link Existing Child
          </button>

          <button
            type="button"
            disabled={!selectedId}
            onClick={async () => {
              if (!selectedId) return;
              const name = window.prompt("New spouse full name:");
              if (!name?.trim()) return;
              try {
                const newId = await createPersonQuick(name.trim());
                await linkSpouse(selectedId, newId);
                await loadTree(selectedId);
              } catch (e: any) {
                setError(String(e?.message ?? e));
              }
            }}
          >
            Add Spouse
          </button>

          <button
            type="button"
            disabled={!selectedId}
            onClick={async () => {
              if (!selectedId) return;
              const existingId = window.prompt("Existing spouse ID to link:");
              if (!existingId?.trim()) return;
              try {
                await linkSpouse(selectedId, existingId.trim());
                await loadTree(selectedId);
              } catch (e: any) {
                setError(String(e?.message ?? e));
              }
            }}
          >
            Link Existing Spouse
          </button>

          <button
            type="button"
            disabled={!selectedId || !treeData}
            onClick={async () => {
              if (!selectedId || !treeData) return;
              const name = window.prompt("New sibling full name:");
              if (!name?.trim()) return;

              try {
                const parentIds = getParentIds(selectedId);
                if (parentIds.length === 0) {
                  setError("NO_PARENTS_FOR_SELECTED: add at least 1 parent first.");
                  return;
                }

                const newId = await createPersonQuick(name.trim());
                for (const pid of parentIds) {
                  await linkParentChild(pid, newId);
                }
                await loadTree(selectedId);
              } catch (e: any) {
                setError(String(e?.message ?? e));
              }
            }}
          >
            Add Sibling
          </button>

          <Link href="/app" style={{ textDecoration: "none" }}>
            <button type="button">List View</button>
          </Link>
        </div>
      </div>

      {error ? <p style={{ marginTop: 12 }}>{error}</p> : null}

      {!centerId ? (
        <div style={{ marginTop: 16, border: "1px solid #ddd", borderRadius: 10, padding: 12 }}>
          Missing centerId.
          <div style={{ marginTop: 8, opacity: 0.8 }}>
            Go to <code>/app</code> and click “Pedigree View”.
          </div>
        </div>
      ) : !treeData ? (
        <p style={{ marginTop: 16 }}>Loading pedigree…</p>
      ) : (
        <div style={{ marginTop: 16 }}>
          <PedigreeCanvas
            data={treeData}
            onSelectPerson={(id) => {
              window.location.href = `/pedigree?centerId=${encodeURIComponent(id)}`;
            }}
          />
        </div>
      )}
    </main>
  );
}